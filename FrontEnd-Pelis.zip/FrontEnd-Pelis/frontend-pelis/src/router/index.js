// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import Inicio from '@/views/Inicio.vue'

const routes = [{ path: '/', name: 'Inicio', component: Inicio }]

export default createRouter({ history: createWebHistory(), routes })

