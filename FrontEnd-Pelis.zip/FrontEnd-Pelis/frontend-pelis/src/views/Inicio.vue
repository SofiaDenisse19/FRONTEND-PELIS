<script setup>
import { ref, onMounted, computed } from 'vue'
import { getPeliculasUsuario } from '@/services/api'

// estado
const peliculas = ref([])       // vendrán del backend
const cargando = ref(true)
const error = ref(null)

// al montar, traer películas
onMounted(async () => {
  try {
    const data = await getPeliculasUsuario()
    // si el servicio devuelve listado o un objeto con { peliculas: [...] }
    peliculas.value = Array.isArray(data) ? data : (data?.peliculas || data?.items || [])
  } catch (e) {
    error.value = e.message || 'Error'
  } finally {
    cargando.value = false
  }
})

// fallbacks/derivados y helpers para secciones (Top5, Estrenos, Hero)
const staticHero = [
  { id: 's1', titulo: 'Matrix', descripcion: 'La realidad no es lo que parece.', img: '/peliculas/matrix-horizontal.webp' },
  { id: 's2', titulo: 'Inception', descripcion: '¿Y si el sueño fuese real?', img: '/peliculas/inception-horizontal.webp' },
  { id: 's3', titulo: 'Parasite', descripcion: 'Una sátira brillante… y oscura.', img: '/peliculas/parasite-vertical.webp' }
]

const heroSlides = computed(() => (peliculas.value && peliculas.value.length >= 3) ? peliculas.value.slice(0, 3) : staticHero)
const topFive = computed(() => (peliculas.value && peliculas.value.length) ? peliculas.value.slice(0, 5) : staticHero.slice(0, 5))
const releases = computed(() => (peliculas.value && peliculas.value.length >= 3) ? peliculas.value.slice(0, 3) : staticHero.slice(0, 3))

function getHeroImg(p) {
  if (!p) return '/peliculas/matrix-horizontal.webp'
  return p.imgHorizontal || p.img_horizontal || p.img || p.imagen || p.poster || p.imgFrente || p.img_frente || p.imagen_horizontal || p.imagenHorizontal || p.hero || p.cover || p.portada || ((p.titulo) ? `/peliculas/${String(p.titulo).toLowerCase().replace(/\s+/g,'-')}-horizontal.webp` : null) || '/peliculas/matrix-horizontal.webp'
}

function getPoster(p) {
  if (!p) return '/peliculas/matrix-vertical.jpg'
  return p.imgFrente || p.img_frente || p.img || p.imagen || p.poster || p.cover || p.portada || '/peliculas/matrix-vertical.jpg'
}

// ref para controlar el scroll horizontal del top-list
const topListRef = ref(null)

const computeScrollAmount = () => {
  const el = topListRef.value
  if (!el) return 300
  const card = el.querySelector('.top-card')
  if (!card) return 300
  const style = window.getComputedStyle(el)
  const gap = parseFloat(style.gap) || 32
  return Math.round(card.offsetWidth + gap)
}

function scrollTopPrev() {
  const el = topListRef.value
  if (!el) return
  el.scrollBy({ left: -computeScrollAmount(), behavior: 'smooth' })
}

function scrollTopNext() {
  const el = topListRef.value
  if (!el) return
  el.scrollBy({ left: computeScrollAmount(), behavior: 'smooth' })
}
</script>

<template>
  <div data-bs-theme="dark">
  <!-- CARRUSEL (3 imágenes horizontales del /public/peliculas) -->
  <!-- full-bleed: ocupar todo el ancho de la ventana (salir del contenedor central) -->
  <div id="carousel1" class="carousel slide full-bleed" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carousel1" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carousel1" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carousel1" data-bs-slide-to="2" aria-label="Slide 3"></button>
      </div>

      <div class="carousel-inner">
        <!-- Usa tus 3 horizontales que guardaste en /public/peliculas/ -->
        <div class="carousel-item active">
          <img src="/peliculas/matrix-horizontal.webp" class="d-block w-100" alt="Matrix" />
          <div class="carousel-caption hero-caption hero-content">
            <span class="brand d-flex align-items-center">
                <img src="/peliculas/logo.png" alt="logo" class="brand-logo" onerror="this.onerror=null;this.src='/vite.svg'" />
              <strong class="brand-text">StreamsUTP</strong>
            </span>
            <h1 class="hero-title">Matrix</h1>
            <p class="hero-desc">La realidad no es lo que parece.</p>
            <div class="hero-actions">
              <a href="#" class="btn btn-light me-2">
                <i class="fa-solid fa-play"></i> Reproducir
              </a>
            </div>
          </div>
        </div>

        <div class="carousel-item">
          <img src="/peliculas/inception-horizontal.webp" class="d-block w-100" alt="Inception" />
          <div class="carousel-caption hero-caption hero-content">
            <span class="brand d-flex align-items-center">
                <img src="/peliculas/logo.png" alt="logo" class="brand-logo" onerror="this.onerror=null;this.src='/vite.svg'" />
              <strong class="brand-text">StreamsUTP</strong>
            </span>
            <h1 class="hero-title">Inception</h1>
            <p class="hero-desc">¿Y si el sueño fuese real?</p>
            <div class="hero-actions">
              <a href="#" class="btn btn-light me-2">
                <i class="fa-solid fa-play"></i> Reproducir
              </a>
            </div>
          </div>
        </div>

        <div class="carousel-item">
          <!-- No existía parasite-horizontal.webp en public/peliculas; usamos la versión vertical disponible -->
          <img src="/peliculas/parasite-horizontal.webp" class="d-block w-100" alt="Parasite" />
          <div class="carousel-caption hero-caption hero-content">
            <span class="brand d-flex align-items-center">
                <img src="/peliculas/logo.png" alt="logo" class="brand-logo" onerror="this.onerror=null;this.src='/vite.svg'" />
              <strong class="brand-text">StreamsUTP</strong>
            </span>
            <h1 class="hero-title">Parasite</h1>
            <p class="hero-desc">Una sátira brillante… y oscura.</p>
            <div class="hero-actions">
              <a href="#" class="btn btn-light me-2">
                <i class="fa-solid fa-play"></i> Reproducir
              </a>
            </div>
          </div>
        </div>
      </div>

      <button class="carousel-control-prev" type="button" data-bs-target="#carousel1" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Anterior</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carousel1" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Siguiente</span>
      </button>
    </div>

    <!-- SECCIÓN: Top 5 y Estrenos destacados (copiado del diseño) -->
    <main class="container my-5">
      <section class="text-center mb-5">
        <!-- Top 5 películas más vistas hoy -->
        <section class="top-five container position-relative">
          <button class="top-nav-btn top-prev" aria-label="Anterior" @click="scrollTopPrev">
            <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
          </button>
          <div class="section-header">
            <i class="fa-solid fa-fire fa-lg text-primary"></i>
            <h3 class="m-0">Top 5 películas más vistas hoy</h3>
          </div>

          <div class="top-list" ref="topListRef">
            <div class="top-card" v-for="(p, i) in topFive" :key="p.id || p.titulo || i">
              <div class="rank">{{ i + 1 }}</div>
              <div class="poster">
                <img :src="getPoster(p)" :alt="p.titulo" />
                <div class="play-overlay"><i class="fa-solid fa-play"></i></div>
              </div>
              <div class="card-title">{{ p.titulo }}</div>
            </div>
          </div>
          <button class="top-nav-btn top-next" aria-label="Siguiente" @click="scrollTopNext">
            <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
          </button>
        </section>

        <!-- Estrenos destacados (nuevo diseño) -->
        <section class="releases-section mt-4">
          <div class="section-header d-flex align-items-center mb-3">
            <i class="fa-solid fa-star fa-lg text-warning"></i>
            <h3 class="m-0"> Estrenos destacados</h3>
          </div>
          <div class="releases-grid d-flex">
            <div class="release-card" v-for="(r, idx) in releases" :key="r.id || r.titulo || idx">
              <div class="poster-wrap">
                <img :src="getHeroImg(r)" :alt="r.titulo" />
                <span class="badge-new">Recién agregado</span>
              </div>
              <div class="release-title">{{ r.titulo }}</div>
            </div>
          </div>
        </section>
      </section>

      <!-- SECCIÓN: Todas las películas (desde backend) -->
      <div class="section-header d-flex justify-content-center align-items-center mb-4">
        <i class="fa-solid fa-film fa-lg text-primary me-2"></i>
        <h2 class="m-0">Todas las películas</h2>
      </div>

      <div v-if="cargando" class="text-center text-muted py-5">Cargando…</div>
      <div v-else-if="error" class="alert alert-danger">{{ error }}</div>

      <div v-else class="row g-3">
        <div
          v-for="p in peliculas"
          :key="p.id"
          class="col-6 col-md-3 text-center"
        >
          <!-- portada vertical: p.imgFrente (ruta tipo /peliculas/matrix-vertical.jpg) -->
          <img
            :src="getPoster(p)"
            :alt="p.titulo"
            class="img-fluid rounded"
            style="aspect-ratio: 2/3; object-fit: cover;"
          />
          <p class="mt-2 fw-semibold">{{ p.titulo }}</p>
        </div>

        <div v-if="!peliculas.length" class="col-12 text-center">
          <p class="text-muted">No hay películas disponibles en este momento.</p>
        </div>
      </div>
    </main>
  </div>
</template>

<style scoped>
/* ——— Estilos clave del hero/carrusel ——— */
/* Aplicar sólo a la imagen principal del slide (hijo directo), no a otros img dentro del caption */
.carousel-item > img {
  width: 100%;
  max-height: 80vh;
  height: auto;
  object-fit: cover;
  display: block;
  filter: brightness(0.7);
}
.hero-caption {
  left: 6%;
  right: auto;
  text-align: left;
  top: 50%;
  transform: translateY(-50%);
  /* reducir ancho para que el texto tenga más impacto visual */
  width: 38%;
  z-index: 5;
  position: absolute;
}
.hero-title {
  /* Más grande y responsive: se adapta al ancho de la ventana para emular la referencia */
  font-size: clamp(2.2rem, 6.5vw, 6.4rem);
  line-height: 1;
  color: #ffffff;
  font-weight: 800;
  /* usar Montserrat para acercar la tipografía al ejemplo */
  font-family: 'Montserrat', system-ui, Avenir, Helvetica, Arial, sans-serif;
  letter-spacing: -0.6px;
  text-shadow: 0 3px 12px rgba(0,0,0,0.6);
  margin: 0 0 0.4rem 0;
}
.hero-desc {
  color: #e6e6e6;
  margin-bottom: 1.2rem;
  font-size: clamp(1rem, 1.8vw, 1.5rem);
  max-width: 90%;
  opacity: 0.95;
  font-family: 'Montserrat', system-ui, Avenir, Helvetica, Arial, sans-serif;
  font-weight: 400;
  letter-spacing: -0.2px;
}

/* Ajustes del botón para que sea visible y proporcional */
.hero-actions .btn {
  padding: 0.75rem 1.25rem;
  font-size: 1.05rem;
}


/* Responsive */
@media (max-width: 992px) {
  .hero-caption { width: 65%; }
  .hero-title { font-size: 2rem; }
  .hero-desc { font-size: 0.95rem; }
  .carousel-item img { max-height: 520px; }
}
@media (max-width: 576px) {
  .hero-caption { width: 90%; }
  .hero-title { font-size: 1.3rem; }
  .hero-desc { font-size: 0.8rem; }
  .carousel-item img { max-height: 320px; }
}

/* Forzar color blanco en títulos y nombres dentro de Top 5 y Estrenos */
.section-header h3 {
  color: #ffffff !important;
}
.top-card .card-title {
  color: #ffffff !important;
  font-weight: 700;
  margin-top: 0.6rem;
}
.releases-section .section-header h3 {
  color: #ffffff !important;
}

/* Ajustes menores para legibilidad */
.top-card .poster img { height: 260px; }
.top-list { gap: 5rem; }

/* full-bleed helper: hace que un elemento ocupe todo el ancho de la ventana
   (útil para hero/banner que debe salirse del contenedor centrado) */
.full-bleed {
  position: relative;
  left: 50%;
  right: 50%;
  margin-left: -50vw;
  margin-right: -50vw;
  width: 100vw;
  overflow: hidden;
}

/* brand/logo en el hero */
.brand-logo {
  height: 34px; /* aumenté para que coincida con la referencia */
  width: auto;
  margin-right: 0.8rem;
  object-fit: contain;
  max-height: 34px;
  max-width: 160px;
  display: inline-block;
  z-index: 8; /* encima del fondo */
}
.brand-text {
  color: #fff;
  font-size: 1.25rem;
  font-weight: 800;
  line-height: 1;
}

/* Todas las películas: títulos y nombres en blanco */
.section-header h2 {
  color: #ffffff !important;
}
.row .fw-semibold {
  color: #ffffff !important;
  font-weight: 700;
}
.row .text-muted {
  color: rgba(255,255,255,0.7) !important;
}

/* Estilos para flechas del Top 5: circulares y centradas verticalmente */
.top-nav-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid rgba(30,110,255,0.9);
  background: rgba(0,0,0,0.45);
  color: #fff;
  cursor: pointer;
  z-index: 10;
  box-shadow: 0 6px 18px rgba(0,0,0,0.5);
}
.top-nav-btn i { font-size: 1.1rem; }
.top-nav-btn.top-prev { left: 10px; }
.top-nav-btn.top-next { right: 10px; }
.top-nav-btn:hover { transform: translateY(-50%) scale(1.06); }
</style>

<!-- FontAwesome para iconos del botón reproducir -->
<link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
/>
