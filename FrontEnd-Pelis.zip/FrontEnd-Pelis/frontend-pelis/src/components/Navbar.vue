<template>
  <header class="site-navbar">
    <div class="nav-inner container-fluid d-flex align-items-center justify-content-between px-4">
      <div class="nav-left d-flex align-items-center">
        <img src="/peliculas/logo.png" alt="logo" class="nav-logo" onerror="this.onerror=null;this.src='/vite.svg'"/>
        <span class="nav-brand">StreamsUTP</span>
      </div>

      <nav class="nav-right d-flex align-items-center">
        <router-link to="/" class="nav-link me-3">INICIO</router-link>
        <button class="btn btn-primary btn-sm me-2 btn-login">Iniciar sesión</button>
        <button class="btn btn-danger btn-sm btn-sub">SUSCRÍBETE</button>
      </nav>
    </div>
  </header>
</template>

<script setup>
// simple presentational navbar. If needed we can add reactive state (auth) later.
</script>

<style scoped>
.site-navbar {
  background: #2b2b2b; /* oscuro similar a la referencia */
  color: #fff;
  height: 56px;
  display: flex;
  align-items: center;
  box-shadow: 0 1px 0 rgba(0,0,0,0.6) inset;
  position: sticky;
  top: 0;
  z-index: 1000;
}
.nav-inner { max-width: 1280px; margin: 0 auto; }
.nav-left { gap: 0.6rem; }
.nav-logo { height: 26px; width: auto; margin-right: 0.6rem; }
.nav-brand { font-weight: 700; font-size: 0.95rem; color: #fff; }
.nav-right .nav-link { color: rgba(255,255,255,0.9); text-decoration: none; font-weight:600; }
.nav-right .nav-link.router-link-active { color: #fff; }
.btn-login { background: #0b75ff; border-color: rgba(11,117,255,0.95); box-shadow: none; }
.btn-sub { background: #ff2b2b; border-color: #ff2b2b; margin-left: 0.5rem; }
.btn-login, .btn-sub { padding: 6px 12px; border-radius: 20px; }

@media (max-width: 576px) {
  .nav-inner { padding-left: 12px; padding-right: 12px; }
  .nav-right .nav-link { display: none; }
}
</style>
