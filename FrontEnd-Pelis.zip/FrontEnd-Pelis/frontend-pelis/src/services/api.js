const BASE = import.meta.env.VITE_API_BASE || '' // con proxy puedes dejarlo vacío

export async function getPeliculasUsuario() {
  const r = await fetch(`${BASE}/api/peliculas/usuario`)
  if (!r.ok) throw new Error('Error al cargar películas')
  return r.json()
}
